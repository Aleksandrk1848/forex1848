Change Log
==========

## Version 1.1.6

_2019-09-23_

 *  Fix: double "reset filters" button.
 *  Fix: unnecessary divider in search toolbar.

## Version 1.1.3

_2019-09-12_

 *  Fix: RTL languages partially disabled (there is no easy fix for hotels part, it will be fixed
    later). Now they fallback to English.
 
 *  Fix: 403 error code in search. We fixed proguard settings for travel-sdk library. You can
    re-enable proguard for release builds.
    
 *  Fix: gray blank line above keyboard in browser. Navigation buttons were restored.
 
## Version 1.1.0

 *  New: multilanguage support

## Version 1.0.0

 *  Initial release
